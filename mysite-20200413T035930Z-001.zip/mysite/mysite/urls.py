from django.contrib import admin
from django.urls import path, include

from mysite.core import views


urlpatterns = [
    path('', views.home, name='home'),
    path('signup/', views.signup, name='signup'),
    path('todo/', views.todo, name='todo'),
    path('delete/<list_id>',views.delete,name="delete"),
    path('cross_off/<list_id>',views.cross_off,name="cross_off"),
    path('uncross/<list_id>',views.uncross,name="uncross"),
    path('edit/<list_id>',views.edit,name="edit"),
    path('secret/', views.secret_page, name='secret'),
    path('secret2/', views.SecretPage.as_view(), name='secret2'),
    path('accounts/', include('django.contrib.auth.urls')),
    path('admin/', admin.site.urls),
]
