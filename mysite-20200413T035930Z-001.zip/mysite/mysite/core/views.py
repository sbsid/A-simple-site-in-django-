from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import List
from .forms import ListForm
from django.contrib import messages


def home(request):
    count = User.objects.count()
    return render(request, 'home.html', {
        'count': count
    })


def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {
        'form': form
    })


@login_required
def todo(request):
  if request.method == 'POST' :
    form = ListForm(request.POST or None)
    if form.is_valid():
           form.save()
           all_items = List.objects.all
           messages.success(request, ('Item Has Been Added To List !!!'))
           return render(request, 'todo.html', {'all_items': all_items})

  else :
    all_items = List.objects.all
    return render(request, 'todo.html', {'all_items': all_items})

def delete(request, list_id):
    item = List.objects.get(pk=list_id)
    item.delete()
    messages.success(request, ('Item Has Been Deleted Successfully!!!! '))
    return redirect('todo')

def cross_off(request, list_id):
    item = List.objects.get(pk=list_id)
    item.completed = True
    item.save()
    return redirect('todo')

def uncross(request, list_id):
    item = List.objects.get(pk=list_id)
    item.completed = False
    item.save()
    return redirect('todo')

def edit(request, list_id):
    if request.method == 'POST':
        item = List.objects.get(pk=list_id)

        form = ListForm(request.POST or None , instance=item)

        if form.is_valid():
            form.save()
            messages.success(request, ('Item Has been Edited!!!'))
            return redirect('todo')
    else:
        item = List.objects.get(pk=list_id)
        return render(request, 'edit.html',{'item': item})

def secret_page(request):
    return render(request, 'secret_page.html')


class SecretPage(LoginRequiredMixin, TemplateView):
    template_name = 'secret_page.html'

